<?php
/* Template Name: Person Register Page */

get_header();
?>
<section id="primary">
		<main id="main" class="max-w-[1200px] m-auto">
            

            <!-- Hero Section -->
            <?php get_template_part('template-parts/components/hero') ?>
            
            <!-- Personen Section -->

                <!-- get the personen from relationship field personen -->
                <?php
                    $headline;
                    $uberschrift = get_field('uberschrift');
                    if ($uberschrift) {
                        $headline = $uberschrift;
                    } else {
                        $headline = 'Personen';
                    }
                    $personen = get_field('personen');
                    wp_reset_postdata();
                ?>
                
                <!-- Section Header Data -->
                <?php 
                    $argsHeader = [
                        'tag' => 'h2',
                        'text' => $headline,
                    ];
                ?>
            
                <?php if ($personen): ?>   
                <section id="personen-preview" class="py-10 px-4">
                
                <!-- Section Header -->
                <?php get_template_part('template-parts/components/section-header', null, $argsHeader) ?>

                <!-- Personen Tiles -->
                <div class="grid gap-4 md:grid-cols-3">
                    <?php foreach ( $personen as $post ) : setup_postdata( $post ); 
                    ?>
                        
                        <!-- Display the post using post-tile template part -->
                         <div class="">
                        <?php get_template_part('template-parts/components/person-tile') ?>
                        </div>

                    <?php endforeach; wp_reset_postdata(); ?>
                </div>
            </section>
            <?php endif; ?>
            <!-- End Personen Section -->
        </main>
</section>

<?php get_footer(); ?>
