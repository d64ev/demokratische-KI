<?php
/* Template Name: Custom Home Page */

get_header();
?>
<section id="primary" class="max-w-screen overflow-x-hidden relative overflow-clip">
    <img class="absolute right-0 hidden  md:block lg:right-0 top-10 -z-10 h-[80vh] max-h-[900px] object-cover opacity-50" src="<?php echo get_template_directory_uri(); ?>/assets/images/background-logo.png" alt="CCDKI Home Background">
    <!-- <img class="absolute right-0 hidden lg:block md:right-[8vw] rounded-lg top-16 z-0 w-[40vw] max-w-[450px] h-auto aspect-video object-cover" src="<?php echo get_template_directory_uri(); ?>/assets/images/home-1.png" alt="D64 Home Background">
    <img class="absolute right-0 hidden lg:block md:right-[2vw] rounded-lg top-72 z-0 w-[30vw] max-w-[340px] h-auto max-lg:aspect-square lg:aspect-video object-cover" src="<?php echo get_template_directory_uri(); ?>/assets/images/home-2.jpg" alt="D64 Home Background">
    <img class="absolute right-0 hidden lg:block md:right-[14vw] rounded-lg  top-[440px] z-0 w-[26vw] max-w-[310px] h-auto max-lg:aspect-square lg:aspect-video object-cover" src="<?php echo get_template_directory_uri(); ?>/assets/images/home-3.jpg" alt="D64 Home Background"> -->
    <main id="main" class="front-page max-w-[1200px] m-auto">
        
        <!-- Hero Section -->
        <?php 
        $heroImage1 = get_field('bild-1');

        
        ?>
        <!-- mobile hero image -->
        <div class="relative md:hidden">
            <div class=" bg-gradient-to-b from-transparent to-d64blue-50 sm:to-white w-full h-20 absolute left-0 right-0 bottom-0"></div>
            <?php if ($heroImage1) : ?>
                <img class="w-full max-h-[320px] object-cover aspect-video" src="<?php echo $heroImage1['url']; ?>" alt="D64 Home Background">
            <?php else : ?>
                <img class="w-full max-h-[320px] object-cover aspect-video" src="<?php echo get_template_directory_uri(); ?>/assets/images/home-2.jpg" alt="D64 Home Background">
            <?php endif; ?>
        </div>
        <div class="py-0 sm:py-6  sm:pt-0">
            <section class="pb-12 pt-8 sm:py-20 bg-d64blue-50 sm:bg-transparent" id="hero-content">
                <div class="flex flex-col gap-8 md:gap-10 px-4 max-w-[960px]">
                <div class="prose prose-strong:text-d64blue-900  prose-img:my-0 lg:max-w-[960px] prose-h1:font-bold prose-h1:!text-[clamp(2rem,1.118rem+3.529vw,3.5rem)]  prose-ul:list-inside">
                     <?php the_content() ?>
                </div>

                <!-- links that look like buttons -->
                <?php if( have_rows('hero_links') ): ?>
                    <div class="flex flex-row flex-wrap gap-1">
                    <?php while( have_rows('hero_links') ): the_row(); 

                        // Get the link sub-field values
                        $link = get_sub_field('hero_link');
                        $url = $link['url'];
                        $title = $link['title'];
                        $target = $link['target'] ? $link['target'] : '_self';
                        ?>
                        <a 
                            href="<?php echo esc_url($url); ?>" 
                            target="<?php echo esc_attr($target); ?>"
                            class="flex px-4 py-[10px] text-base rounded-full font-medium  max-w-content  bg-lila-500 text-white hover:underline transition-colors">
                                <?php echo esc_html($title); ?>
                        </a>
                        <?php endwhile; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>


        <!-- Time Line -->
        <?php if (have_rows('tiles')): ?>
            <!-- Section Header -->
             <div class="pb-8 pt-10 lg:pb-24">
            <?php 
                $argsHeader = [
                    'tag' => 'h2',
                    'text' => 'Time Line',
                ];
            ?>
            <?php
                get_template_part('template-parts/components/section-header', null, $argsHeader);
            ?>
             <div class=" gap-4 flex px-4 w-screen overflow-x-scroll no-scrollbar">
                 <?php
                $index = 0; 
                while (have_rows('tiles')) : the_row();
                    $label = get_sub_field('label');
                    $datum = get_sub_field('datum');
                    $icon = get_sub_field('icon');
                    $link = get_sub_field('link');
                    $pointerClass = empty($link) ? 'pointer-events-none' : '';
                    $bgColor = ($index === 1 || $index === 3) ? "bg-lila-500/20" : 
                        (($index === 2 || $index === 4) ? "bg-lila-500" : "bg-lila-500/60");
                    ?>
                    <a href="<?php echo $link ?>" class="group flex flex-col gap-4 w-52 <?php echo $pointerClass ?>">
                        <h3 class="group-hover:underline text-balance font-bold text-d64blue-900 "><?php echo  $label?></h3>
                        <div class="w-52 h-28 group-hover:translate-x-1 transition-transform flex items-center justify-center [clip-path:polygon(0_0,90%_0,100%_50%,90%_100%,0_100%,10%_50%)] <?php echo $bgColor; ?>">
                            <?php if ($icon): ?>
                                <div class="flex flex-col w-12 h-12 ">
                                    <img src="<?php echo esc_url($icon['url']); ?>" alt="<?php echo esc_attr($icon['alt']); ?>" />
                                </div>
                            <?php endif; ?>
                        </div>
                        <p class="font-medium text-lila-500 "><?php echo $datum ?></p>
                        </a>
                    <?php 
                $index++;
                endwhile; ?>
            </div>
            </div>
        <?php endif; ?>

        <!-- Events Section -->
        <?php
        // Check if The Events Calendar is active
        if (function_exists('tribe_get_events')) {
            // Get the next 3 upcoming events
            $events = tribe_get_events([
                'posts_per_page' => 3,
                'start_date' => 'now',
                'orderby' => ['event_date' => 'ASC']
            ]);

            // Check if there are events, if not, don't display the section
            if (!empty($events)) {
                // Section Header
                $argsHeader = [
                    'tag' => 'h2',
                    'text' => 'Veranstaltungen',
                ];
                ?>
                <section id="events-preview" class="pb-6 pt-10 px-4 sm:pb-6 md:pb-8 lg:py-10">
                    <?php
                    get_template_part('template-parts/components/section-header', null, $argsHeader);
                    ?>
                    <!-- Event Tiles -->
                    <div id="events-grid">
                        <?php 
                        global $post;
                        foreach ($events as $post) {
                            setup_postdata($post);
                            get_template_part('template-parts/components/event-tile');
                        }
                        wp_reset_postdata();
                        ?>
                    </div>
                    <?php
                    // Get total number of future events for the button condition
                    $total_events = tribe_get_events([
                        'posts_per_page' => -1,
                        'start_date' => 'now',
                        'fields' => 'ids'
                    ]);

                    if (count($total_events) > 3) {
                        ?>
                        <div class="py-6 sm:py-10 md:py-14">
                            <a
                                href="<?php echo get_site_url(); ?>/veranstaltungen"
                                class="text-lg font-medium sm:m-auto flex items-center gap-1 max-w-max px-4 py-2 hover:bg-d64gray-50 hover:gap-2 transition-all"
                            >
                                <span>Alle Veranstaltungen anzeigen</span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                            </a>
                        </div>
                        <?php
                    } else {
                        ?> <div class="pb-8 md:p-12"></div> <?php
                    }
                    ?>
                </section>
            <?php 
            }
        } 
        ?>
        <!-- End Events Section -->

        
        <!-- Blog Section -->

            <!-- get the last 3 posts -->
            <?php
                $args = array(
                    'posts_per_page' => 3,
                );
                $lastposts = get_posts( $args );
                wp_reset_postdata();
            ?>

            <!-- Section Header Data -->
            <?php 
                $argsHeader = [
                    'tag' => 'h2',
                    'text' => 'Aktuelles',
                ];
            ?>
            <section id="blog-preview" class="py-6 px-4 sm:py-6 md:py-8 lg:py-10">
            
            <!-- Section Header -->
            <?php get_template_part('template-parts/components/section-header', null, $argsHeader) ?>

            <!-- Post Tiles -->
            <div class="grid gap-6 md:gap-4 md:grid-cols-3">
                <?php foreach ( $lastposts as $post ) : setup_postdata( $post ); ?>
                    
                    <!-- Display the post using post-tile template part -->
                    <?php get_template_part('template-parts/components/post-tile') ?>

                <?php endforeach; wp_reset_postdata(); ?>
            </div>
            <div class="py-6 sm:py-10 md:py-14">
                <a 
                    href = "<?php echo get_site_url(); ?>/aktuelles"
                    class="text-lg font-medium sm:m-auto flex items-center gap-1 max-w-max px-4 py-2 hover:bg-d64gray-50 hover:gap-2 transition-all"
                >
                    <span>Alle Beiträge anzeigen</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                </a>
            </div>
        </section>
        <!-- End Blog Section -->

        <!-- Ergebnisse Section -->
          <!-- Section Header Data -->
            <?php 
                $argsHeader = [
                    'tag' => 'h2',
                    'text' => 'Ergebnisse',
                ];
            ?>
        <section id="results" class="py-6 px-4 sm:py-6 md:py-8 lg:py-10 mb-8">
        
            <!-- Section Header -->
            <?php get_template_part('template-parts/components/section-header', null, $argsHeader) ?>
            <!-- Section Content -->
            <div class="flex flex-col gap-4 lg:grid lg:gap-8 lg:grid-cols-2">
                <?php $ergebnisseBild = get_field('ergebnisse_bild'); ?>
                <?php if ($ergebnisseBild) : ?>
                    <img src="<?php echo esc_url($ergebnisseBild['url']); ?>" class="max-w-screen-sm w-full" alt="<?php echo esc_attr($ergebnisseBild['alt']); ?>">
                <?php endif; ?>
                <?php if (get_field('ergebnisse_text')) : ?>
                    <div class="max-w-screen-md  prose">
                        <?php the_field('ergebnisse_text'); ?>
                    </div>
                <?php endif; ?>
            </div>

            </section>

        <!-- Dimensionen KI-Wertekompass Section -->
            <!-- Section Header Data -->
            <?php 
                $argsHeader = [
                    'tag' => 'h2',
                    'text' => 'KI-Wertekompass',
                ];
            ?>
            <section id="ki-wertekompass" class="py-6 px-4 sm:py-6 md:py-8 lg:py-10">
            
                <!-- Section Header -->
                <?php get_template_part('template-parts/components/section-header', null, $argsHeader) ?>
            
                <!-- Slider Container -->
                <div id="slider-container" class="max-w-5xl lg:mx-auto px-4 py-6 border border-lila-500 sm:px-6 sm:py-12">
                <div class="space-y-6">
                    <!-- Slider 1 -->
                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">Sicherheit</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">Offenheit</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-full max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>

                <!-- Slider 2 -->
                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">Konservativ</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">Explorativ</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-full max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>

                <!-- Remaining sliders follow same pattern -->
                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">Präzision</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">Imagination</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-full max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>

                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">Menschliche Autor:innenschaft</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">KI-generierte Inhalte</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-full max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>

                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">KI-Minimalismus</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">KI-Maximierung</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-[100%+1rem] max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>
            </div>
        </div>

            <!-- Download Button -->
            <div class="flex mx-4 lg:mx-auto justify-end max-w-5xl">
                <button id="downloadBtn" class="mt-6 px-4 py-2 bg-lila-500 text-white rounded hover:bg-lila-500/80 transition-colors">
                    Screenshot generieren
                </button>
            </div>
        </section>
    </main>
</section>
            

<?php get_footer(); ?>

<style>
        .slider-thumb {
            position: absolute;
            height: 28px;
            width: 28px;
            background: #821f8b;
            border-radius: 50%;
            top: 2px;
            margin-left: -14px;
            cursor: pointer;
        }
    </style>