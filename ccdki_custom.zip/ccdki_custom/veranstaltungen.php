<?php
/* Template Name: Veranstaltungen Page */

get_header();
?>
<section id="primary">
		<main id="main" class="max-w-4xl m-auto">

        <div class="flex flex-row items-center lg:justify-center xl: pb-0 pt-4 px-4 md:pb-4 md:pt-12 lg:pt-20">
            <h1 class="italic font-medium text-lg sm:text-xl md:text-2xl xl:text-center">Veranstaltungen</h1>
        </div>
            
            <!-- Event Tiles -->
            <section id="events-preview" class="py-6 px-4 sm:py-6 md:py-8 lg:py-10">
                <?php
                    $events = EM_Events::get( array('scope'=>'future', 'limit'=>12) );
                    if ( !empty($events) ) { ?>
                        <div id="" class="flex flex-col gap-4">
                            <?php foreach ( $events as $EM_Event ) {
                                global $wp_query;
                                $wp_query->current_event = $EM_Event;
                                get_template_part('template-parts/components/event-tile');
                                unset($wp_query->current_event);
                            } ?>
                        </div>
                    <?php 
                    } else { ?>
                        <p class="text-lg font-medium">Aktuell sind keine Veranstaltungen geplant.</p>
                        
                    <?php }?>
            </section>
        <!-- End Events Section -->
        </main>
</section>

<?php get_footer(); ?>
