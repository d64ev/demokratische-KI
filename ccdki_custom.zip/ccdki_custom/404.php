<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package d64
 */

get_header();
?>

	<section id="primary" class="min-h-[40vh]">
		<main id="main">

			<div>
				<div class="max-w-2xl m-auto pt-24">
				<header class="page-header text-center">
					<span class="font-medium">404</span>
					<h1 class="text-2xl font-semibold">Seite nicht gefunden</h1>
					<p class="text-lg pt-4 pb-12">Die Seite, die du suchst, existiert nicht.</p>
					<a href="<?php echo get_site_url(); ?>" class="text-lg font-medium text-d64blue-900 hover:text-d64blue-500 transition-colors">Zurück zur Startseite</a>
				</header><!-- .page-header -->

				
				</div>
			</div>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php
get_footer();
