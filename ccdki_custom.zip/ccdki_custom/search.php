<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package d64
 */

get_header();
?>

<section id="primary">
    <main id="main">
		<div class="max-w-[1200px] m-auto px-4 pt-4 pb-16 flex flex-col gap-4">

        <header class="page-header">
            <?php
            printf(
                /* translators: 1: search result title. 2: search term. */
                '<h1 class="page-title pb-4 text-base font-regular">%1$s <span class="font-semibold">%2$s</span></h1>',
                esc_html__( 'Suchbegriff:', 'd64' ),
                get_search_query()
            );
            ?>
        </header><!-- .page-header -->

        <?php

        $post_types = array('post', 'page', 'personen'); // Add any other post types you want

        foreach ($post_types as $type) {
            $query_args = array(
                's' => get_search_query(),
                'post_type' => $type
            );

			$headline; 
			if ( $type === 'post' ) {
				$headline = 'Blogbeiträge';
			} else if ( $type === 'page' ) {
				$headline = 'Seiten';
			} else if ( $type === 'personen' ) {
				$headline = 'Personen';
			}

            $search_query = new WP_Query($query_args);

            if ($search_query->have_posts()) :
				
				echo '<div>';
            	echo '<h2 class="text-xl italic font-medium pb-4 md:pb-6">' . $headline . '</h2>';


				// Set the Layout for the search results based on the post type
				if ($type === 'personen' || $type === 'post') {
					?>
					<div class="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-col-4 gap-1">
					<?php
				} else if ($type === 'page') {
					?>
					<ul class="flex flex-col gap-2">
					<?php
				}

				// Start the Loop.
                while ($search_query->have_posts()) : $search_query->the_post();

					// Display the posts using post-tile template part
					if ( $type === 'post' ) {
						get_template_part('template-parts/components/post-tile');
					// Display the pages
					} else if ( $type === 'page' ) {
						?>
						<li>
							<a 
								href="<?php the_permalink() ?>"
								class="text-2xl font-medium hover:text-d64blue-500 transition-colors "
							>
								<?php the_title(); ?>
							</a>
						</li>
						<?php
					// Display the persons
					} else if ( $type === 'personen' ) {
						get_template_part('template-parts/components/person-tile');
					}
                endwhile;
				?> <?php
				// Set the Layout for the search results based on the post type
				if ($type === 'personen' || $type === 'post') {
					?>
					</div>
					<?php
				} else if ($type === 'page') {
					?>
					</ul>
					<?php
				}

                wp_reset_postdata(); // Reset the loop
				echo '</div>';
            endif;
        }

        // If none of the post types have results, show the "no content" template.
        if( !have_posts() && !isset($search_query) ) {
            get_template_part( 'template-parts/content/content', 'none' );
        }

        ?>
		</div>
    </main><!-- #main -->
</section><!-- #primary -->

<?php
get_footer();
