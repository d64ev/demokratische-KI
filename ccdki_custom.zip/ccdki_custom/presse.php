<?php
/* Template Name: Presse Page */

get_header();
?>

<!-- get the ansprechpartner from relationship field ansprechpartner -->
<?php $ansprechpartner = get_field('ansprechpartner'); ?>

<section id="primary">
    <main id="main" class="max-w-[1200px] m-auto pb-20">            

        <!-- Hero Section -->
        <div class="lg:grid lg:grid-cols-[1fr_352px] gap-4 lg:px-4 xl:px-0">
            <div class="">
                <div class="">
                    <?php get_template_part('template-parts/components/hero') ?>
                </div>


                <!-- Ansprechpartner Section -->
                <?php if ($ansprechpartner) : ?>                    
                    <section class="lg:hidden block pb-10 pt-10 sm:pt-0 lg:max-w-[320px] m-auto max-w-3xl px-4">
                            <h2 class="text-lg sm:text-xl italic m-auto font-medium pb-8">Ansprechperson</h2>
                        <div >
                            <?php foreach ( $ansprechpartner as $post ) : setup_postdata( $post ); ?>
                                
                                <!-- Display the post using post-tile template part -->
                                <?php get_template_part('template-parts/components/person-tile') ?>
                            <?php endforeach; wp_reset_postdata(); ?>
                        </div>
                    </section>
                <?php endif; ?>

                <!-- Tabs -->
                <div class="bg-transparent lg:bg-d64blue-50 lg:rounded-xl">
                    <?php if (get_field('tab')) : ?>
                        <?php get_template_part('template-parts/components/tabs') ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Ansprechpartner Section -->
            <?php if ($ansprechpartner) : ?>     
                <div class="">
                    <section class="hidden lg:block mt-10 pt-4 rounded-xl sm:mt-20 sm:max-w-[320px] lg:bg-d64blue-50">
                        <h2 class="text-lg sm:text-xl italic m-auto font-medium pl-4">Ansprechperson</h2>
                        <div >
                            <?php foreach ( $ansprechpartner as $post ) : setup_postdata( $post ); ?>
                                
                            <!-- Display the post using post-tile template part -->
                                <?php get_template_part('template-parts/components/person-tile') ?>
                            <?php endforeach; wp_reset_postdata(); ?>
                        </div>
                    </section>
                </div>               
            <?php endif; ?>
        </div>
    </main>
</section>

<?php get_footer(); ?>
