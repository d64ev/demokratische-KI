<?php
/**
 * Template part for displaying the header content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */

?>


<header id="masthead" class="relative pb-[86px] lg:pb-[95px]">

	<div id="header-content" data-expanded="false" class="fixed top-0 left-0 right-0 z-20 bg-white bg-opacity-80 backdrop-blur-sm">
		<div id="header-header" class="inner w-full transition-color bg-transparent flex justify-between items-center px-4 py-4 max-w-[1200px] m-auto relative z-50">
			<div id="main-logo" class="logo z-50">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
					<img src="<?php echo get_template_directory_uri() . '/assets/icons/ccdki-logo.png' ?>" alt="Logo CCDKI" class="w-40 md:w-48	" width="416.25" height="130.37">
				</a>
			</div>
			<div id="sub-nav-btn-container" class="hidden absolute h-[54px] w-24 bg-d64gray-50  left-4 top-4 z-[100]">
				<button id="submenu-nav-button" class="rounded-full text-d64blue-500 w-max">
					<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-left pointer-events-none"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
				</button>
			</div>
			<div class="lg:hidden">
				<?php get_template_part( 'template-parts/components/mobile-nav-button' ); ?>
			</div>
			<div class="z-10 hidden lg:block relative">
				<?php get_template_part( 'template-parts/components/desktop-navigation' ); ?>
				<?php get_template_part( 'template-parts/components/search-bar' ); ?>
				
				<div id="search-result-overlay" class="hidden max-h-[80vh] overflow-y-scroll top-20 border bg-white p-2 pt-4 rounded-b-lg w-auto z-10 shadow">
					<div class=" px-2 m-auto">
						<!-- <div class="w-full flex justify-between items-center">
							<h2 class="font-medium pt-4">Suchergebnisse</h2>
							<button 
								type="button"
								class="p-1 m-1 hover:bg-d64gray-100 rounded-full transition-colors"
								id="close-search-overlay"
								aria-label="close search overlay"
							>
								<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide pointer-events-none lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
							</button>
						</div> -->
						<div id="search-results" class="space-y-4 pt-4">
							<div class="">
								<h3 class="font-medium italic text-lg pb-2">Themen</h3>
								<div id="post-results" class="pl-2 results-section"></div>
								<div id="post-pagination" class="mt-2 flex gap-1"></div>
							</div>
							<!-- <div class="border-d64blue-900 border-t pt-2">
								<h3 class="font-medium italic text-lg pb-2">Personen</h3>
								<div id="personen-results" class="results-section"></div>
								<div id="personen-pagination" class="mt-2 flex gap-1"></div>
							</div> -->
							<div class="border-d64blue-900 border-t pt-2">
								<h3 class="font-medium italic text-lg pb-2">Seiten</h3>
								<div id="page-results" class="pl-2 results-section"></div>
								<div id="page-pagination" class="mt-2 flex gap-1"></div>
							</div>
							<div id="no-results" class="hidden pb-1 -translate-y-2">
								<p>Keine Ergebnisse</p>
							</div>
						</div>
					</div>
				</div>

			</div>
			<div class="hidden lg:block">
				<?php get_template_part( 'template-parts/components/nav-icon-bar' ); ?>
			</div>
		</div>
		<?php get_template_part( 'template-parts/components/mobile-navigation' ); ?>
	</div>

</header><!-- #masthead -->
