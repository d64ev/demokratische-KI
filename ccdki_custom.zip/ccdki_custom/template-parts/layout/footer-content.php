<?php
/**
 * Template part for displaying the footer content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */

?>

<footer id="colophon" class="bg-d64blue-100 sm:mt-20 lg:mt-28">
	<div style="" class="py-10 max-w-[1200px] m-auto flex flex-col-reverse px-4 md:flex md:flex-row md:justify-between gap-12 md:gap-8">
		<div class="flex flex-col md:flex-col-reverse gap-12 md:gap-48">
			<?php
			$footer_navigation_items = get_field('footer_links', 'option');
    		if ($footer_navigation_items):
			?>
			<nav class="text-d64blue-800 text-sm font-medium">
				<ul class="style-none flex flex-col md:flex-row gap-2 md:gap-4">
					<?php 
						foreach ($footer_navigation_items as $item) : 
					?> 
 					<li>
						<a href="<?php echo $item['link']['url']?>" class="md:hover:bg-d64blue-50 md:hover:text-d64blue-900 md:py-1 md:px-2 md:rounded-lg transition-colors">
							<?php echo $item['link']['title']; ?>
						</a>
					</li>
					<?php endforeach; ?>
				</ul>
			</nav>
			<?php endif; ?>
			<div id="footer-logo" class="logo z-50">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="max-w-content">
					<img src="<?php echo get_template_directory_uri() . '/assets/icons/ccdki-logo.png' ?>" alt="Logo" class="w-32 md:w-48	" width="600" height="338">
				</a>
			</div>
		</div>
		<div class="block max-w-sm">
			
		</div>
	</div>

</footer><!-- #colophon -->
