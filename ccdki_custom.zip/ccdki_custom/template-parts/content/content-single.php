<?php
/**
 * Template part for displaying single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */

?>

<?php
    $thumbnail_id = get_post_thumbnail_id();
    $thumbnail_post = get_post($thumbnail_id);
    $thumbnail_desc = esc_html($thumbnail_post->post_content);
    
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header  md:pt-12 sm:pt-8 lg:pt-16 xl:pt-20  sm:pb-8 xl:pb-14 <?php if ( !has_post_thumbnail() || has_category('Job') ) { echo 'bg-d64blue-50 pt-4 pb-6 md:pb-12 lg:pb-16 xl:pb-20'; } else { echo 'pb-4 md:pb-10 lg:pb-12 '; } ?>">
		<div class="max-w-3xl px-4 m-auto">
			<?php the_title( '<h1 class="entry-title text-lila-500 font-bold text-2xl sm:text-3xl md:text-4xl md:max-w-full lg:text-5xl">', '</h1>' ); ?>

			<!-- horizontal line -->
			<div class="hidden sm:block w-full h-[1px] md:h-[2px] bg-d64blue-100 sm:my-8 md:my-10 lg:my-12 xl:my-14"></div>

			<!-- date and category, excerpt container -->
			<div class="flex flex-col-reverse pt-2  gap-2 sm:grid sm:grid-cols-3">

				<!-- date, author and category -->
				<aside class="flex sm:flex-col gap-1 text-xs pt-2 sm:pt-1 text-gray-500 md:text-sm">
					<!-- <div class="mr-2 font-medium hover:underline">
						<?php 
							$linked_author = get_field('author'); 
							if ($linked_author) : 
								$post = $linked_author[0]; // assuming the relationship returns an array of post objects
								setup_postdata($post); ?>
								<a href="<?php home_url()?>/aktuelles/?author_id=<?php echo get_the_id() ?>"><?php the_title(); ?></a>
								<?php wp_reset_postdata(); ?>
							<?php endif ?>
					</div> -->
					<div class="flex flex-wrap">
						<div class="mr-2">
							<?php esc_html(the_date()); ?>	
						</div>
						<div class="mr-2 sm_hidden">
							<?php $categories = get_the_category();
								if ( ! empty( $categories ) ) {
									$category = esc_html( $categories[0]->name );   
									$categoryId = esc_html( $categories[0]->term_id ); 
									?> 
									<a class="font-medium break-words" href="<?php home_url()?>/?category_id=<?php echo $categoryId ?>"><?php echo $category; ?></a>
									<?php
								} 
							?>
						</div>
					</div>
				</aside>

				<!-- excerpt -->
				<div class="text-md leading-loose font-medium sm:text-lg sm:col-span-2">
				<?php $excerpt = wp_trim_words(get_the_excerpt(), 37, '...');
                    echo $excerpt; ?>
				</div>
			</div>
		</div>
	</header><!-- .entry-header -->

	<div class="max-w-4xl m-auto">
	<!-- post thumbnail -->
	<?php if ( has_post_thumbnail() && !has_category('Job') ) : ?>
		<div class="aspect-video relative sm:mx-4 sm:overflow-hidden ">	
			<?php d64_post_thumbnail(); ?>
		</div>
		<?php 
			if (!empty($thumbnail_desc)) { echo '<div class="bottom-0  right-0 left-0 w-full  text-[#737373] text-sm font-regular text-end p-2 pt-1 pr-4">' . $thumbnail_desc . '</div>';
		}?>
	<?php endif; ?>

	<div class="px-4 <?php if ( has_post_thumbnail() && !has_category('Job') ) { echo 'pt-4'; } else { echo 'pt-6'; }; ?> sm:pt-8 md:pt-10 lg:pt-12 xl:pt-14 max-w-[1200px] m-auto">
		<div <?php d64_content_class( 'entry-content' ); ?>>
			<?php
			the_content(
				sprintf(
					wp_kses(
						/* translators: %s: Name of current post. Only visible to screen readers. */
						__( 'Continue reading<span class="sr-only"> "%s"</span>', 'd64' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					get_the_title()
				)
			);

			wp_link_pages(
				array(
					'before' => '<div>' . __( 'Pages:', 'd64' ),
					'after'  => '</div>',
				)
			);
			?>
		</div><!-- .entry-content -->
	</div>

	<!-- Author (base on custom field) -->
	<?php
	
		if ($linked_author) : 
			
			// get mitarbeit field from author post
			$mitarbeit = get_field('mitarbeit'); 
			global $mitarbeit_data;
			$mitarbeit_data = $mitarbeit;	
			
			
		    // Set the post data to the related person post
			$post = $linked_author[0]; 
			setup_postdata($post);

			global $linked_author_id;
			$linked_author_id = get_the_id();
			?>

			<div id="author" class="max-w-[640px] px-4 sm:px-0 m-auto pt-10 sm:pt-12 md:pt-14 lg:pt-16 xl:pt-20">
			
				<?php
					// load person-tile template part
					get_template_part('template-parts/components/person-tile');
				?>
			
			</div>

			<?php
			// Reset the post data back to the original post
			wp_reset_postdata();
			
		endif; ?>

	<!-- Form if post has tag "Job" -->
	<?php if (has_category('Job')) : ?>
		<div class="max-w-[640px] m-auto pt-10 sm:pt-12 md:pt-14 lg:pt-16 xl:pt-20">
			<div class="p-4 sm:rounded-xl bg-d64blue-50 flex flex-col gap-6">
				<h3 class="text-lg font-bold ">Bewirb dich direk hier bei D-64</h3>
				<div class="w-full">
				<?php echo do_shortcode('[contact-form-7 id="b2f67e1" title="Job Bewerbung"]'); ?> 
				</div>
			</div>
		</div>
	<?php endif; ?>

	<!-- weiterführende Artikel -->
	<?php if (!has_category('Job')) : ?>
		<footer class="max-w-3xl m-auto">
			
			<!-- horizontal line -->
			<div class="block w-full h-[1px] md:h-[2px] bg-d64blue-900 my-16 lg:my-20 xl:my-24"></div>

			<!-- section header -->
			<?php 
				$argsHeader = [
					'tag' => 'h3',
					'text' => 'Auch Interessant',
				];
			?>
			<?php get_template_part('template-parts/components/section-header', null, $argsHeader) ?>

			<!-- get the last 2 posts and exclude the current one -->
			<?php
				$args = array(
					'posts_per_page' => 2,
					'post__not_in' => array( $post->ID ),
				);
				$lastposts = get_posts( $args );
				wp_reset_postdata();
			?>

			<!-- display last 2 posts with post-tile template part -->
			<div class="grid gap-4  px-4 sm:px-0">
				<?php foreach ( $lastposts as $post ) : setup_postdata( $post ); ?>
					<?php get_template_part('template-parts/components/post-tile') ?>
				<?php endforeach; wp_reset_postdata(); ?>
			</div>
		</footer>
	<?php endif; ?>
</article><!-- #post-${ID} -->

<style>

blockquote {
	padding-left: 1rem !important;
}

</style>