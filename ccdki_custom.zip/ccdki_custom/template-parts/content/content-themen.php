            
<!-- Get the categories and authors -->
<?php
$categories = get_categories();

// filter authors
$author_ids = [];
$unique_author_ids = [];
$posts_with_authors = get_posts(array(
    'post_type' => 'post',
    'numberposts' => -1,
    'meta_query' => array(
        array(
            'key' => 'author',
            'compare' => 'EXISTS'
        )
    )
));

$unique_author_ids = [];

// Initialize an array to hold unique author IDs and titles
$unique_authors = [];

foreach ($posts_with_authors as $post) {
    $author_ids = get_field('author', $post->ID);

    if (is_array($author_ids) && !empty($author_ids)) {
        foreach ($author_ids as $author) {
            if (!array_key_exists($author->ID, $unique_authors)) {
                $unique_authors[$author->ID] = $author->post_title;
            }
        }
    } elseif ($author_ids && !array_key_exists($author_ids->ID, $unique_authors)) {
        $unique_authors[$author_ids->ID] = $author_ids->post_title;
    }
}

// Sort authors by title
uasort($unique_authors, function($a, $b) {
    return strcmp($a, $b);
});

?>

<div class="flex flex-row justify-between items-center pb-4  pt-4 md:pt-12 lg:pt-20">
    <h1 class="italic font-medium text-lg sm:text-xl md:text-2xl text-lila-500">Aktuelles</h1>
    
    <!-- toggle sidebar and filter on mobile -->
    <div class="flex flex-row justify-end lg:hidden">
        <button 
            id="toggle-filter-menu" 
            class="bg-lila-500 text-sm text-white font-medium rounded-full py-1 px-4 border-2 border-none hover:underline" 
            aria-label="Filter ein-/ausblenden"
            aria-expanded="false"
        >
            Suche & Filter 
        </button>
    </div>
</div>
            
<div class="flex flex-col-reverse gap-4 lg:gap-8 lg:grid lg:grid-cols-3">
    <!-- Posts Section -->
    <main class="lg:col-span-2">
        <!-- Posts will be loaded here via AJAX -->
        <?php
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => 10, 
            'post_status' => 'publish',
            'paged' => get_query_var('paged')
        );
        $query = new WP_Query($args);
        
        if ($query->have_posts()) : ?>

        <!-- Display Posts -->
        <div id="posts-container" aria-live="polite" class="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-1 gap-6 sm:gap-8">

        </div>
        
        <?php else : ?>
            <p>Sorry, no posts matched your criteria.</p>
        <?php endif; ?>

        <!-- Custom Pagination -->
        
            <div class="pagination pb-12 sm:pb-0 flex gap-0 sm:gap-2" id="pagination-container">
                
            </div>
        <?php

        wp_reset_postdata();
        ?>
        
    </main>


    <!-- Sidebar with Search and Filter -->
    <div class="h-full">
    
        <!-- Skip Links -->
        <?php 
            $argsSkipLink = [
                'url' => '#posts-container',
                'text' => 'Zu den Posts springen',
            ];
            get_template_part('template-parts/components/skip-link', null, $argsSkipLink);

            $argsSkipLink = [
                'url' => '#author-selection',
                'text' => 'Zur Autoren Auswahl springen',
            ];
            get_template_part('template-parts/components/skip-link', null, $argsSkipLink);
        ?>

        <div id="filter-menu" role="menu" class="relative filter-buttons hidden lg:flex p-4 rounded-none  bg-d64blue-50 lg:sticky lg:top-36">
            <div style="clip-path: polygon(0 0, 100% 100%, 100% 0)" class="absolute bg-white  w-10 h-10 flex top-0 right-0 "></div>
            <div class="flex flex-col gap-7 mb-8 w-full">
            <!-- Search -->
            <div id="text-search-container">
                <h4 class="pb-3 text-sm font-medium text-lila-500 italic">Suche</h4>
                <input type="text" id="text-search-input" class="rounded-full bg-white text-sm font-medium py-2 px-3 w-full" placeholder="Themen durchsuchen...">
            </div>

            <!-- Display Categories -->
            <div class="" id="filter">
                <h4 class="pb-3 text-sm text-lila-500 font-medium italic">Kategorien</h4>

                <!-- Section Header -->
                <div class="category-filters flex flex-wrap gap-1">
                    <?php 
                    $current_category_id = (is_category()) ? get_queried_object_id() : null;
                    $categories = get_categories();
                    foreach ($categories as $category) {
                        $isActive = ($current_category_id == $category->term_id) ? 'active border-d64blue-900' : 'border-d64blue-50';
                        echo '<button class="filter-button text-sm bg-white font-medium rounded-full py-1 px-2 border-2 border-d64blue-50 hover:underline ' . $isActive . '" data-filter-type="category" data-id="' . $category->term_id . '">' . $category->name . '</button>';
                    }
                    ?>
                </div>
            </div>

            <!-- Display Authors -->
            <div class="" id="author-selection">
                <h4 class="pb-3 text-sm font-medium text-lila-500 italic">Autor*innen</h4>
                <div class="author-filters flex flex-wrap gap-1">
                    <?php foreach ($unique_authors as $id => $title): ?>
                        <button 
                            class="filter-button text-sm bg-white font-medium rounded-full py-1 px-2 border-2 border-white hover:underline"
                            data-id="<?php echo $id ?>"
                            data-filter-type="author"
                            role="button"
                            aria-pressed="false"
                            aria-label="Filter Beiträge von Author <?php echo $title ?>"
                        >
                            <?php echo $title; ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<style>

    /* Pagination */
    #pagination-container {
        margin-top: 2rem;
    }

    .page-numbers {
        transition: all .2s ease-in-out;    
        border-radius: .5rem;
        padding: .25rem .75rem ;
    }

    .page-numbers:hover {
        background: rgb(214 222 226);
    }

    .page-numbers.current {
        font-weight: 700;
    }
</style>