<?php
/**
 * Template part for displaying pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */

?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<!-- Hero Section -->
	<?php get_template_part('template-parts/components/hero') ?>

	<!-- Tabs -->
	<?php get_template_part('template-parts/components/tabs') ?>

	<!-- Chronik -->
	<?php if( have_rows('timeline') ): ?>
		<?php get_template_part('template-parts/components/timeline') ?>
	<?php endif; ?>

	<!-- Arbeitsgruppen -->
	<?php if (get_the_title() == 'Arbeitsgruppen') : ?>
		<?php get_template_part('template-parts/components/working-groups') ?>
	<?php endif; ?> 

	<!-- Jobs Section -->
	<?php if (is_page('Jobs')) : ?>
            <?php get_template_part('template-parts/components/jobs') ?>
        <?php endif; ?>
	
	<!-- Mitglied werden Section -->
	<?php if (is_page('Mitglied werden')) : ?>
		<div class="max-w-[640px] px-4 sm:px-0 m-auto pt-10 sm:pt-6">
			<div class="sm:p-4 rounded-xl sm:bg-d64blue-50 flex flex-col gap-6">
				<h3 class="text-lg font-bold ">Mitgliedsantrag</h3>
				<div class="w-full">
				<?php echo do_shortcode('[contact-form-7 id="64be5e3" title="Mitglied werden"]'); ?>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<!-- Scroll Cols Section -->
	<?php get_template_part('template-parts/components/scroll-cols') ?>

	<!-- Gremien Section -->
	<?php if (is_page('Gremien') || is_page('Gremien & Bündnisse')) : ?>
		<?php get_template_part('template-parts/components/gremien') ?>
	<?php endif; ?>

</div><!-- #post-<?php the_ID(); ?> -->
