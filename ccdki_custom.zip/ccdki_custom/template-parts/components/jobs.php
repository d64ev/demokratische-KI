<?php
/**
 * Template part for displaying a list of jobs
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */
?>

<!-- Jobs Section -->
<?php
    $args = array(
        'post_type' => 'post',
        'category_name' => 'job',
        'posts_per_page' => -1,
    );
    $jobs = new WP_Query($args);
?>

<section class="px-4 sm:px-0 max-w-3xl py-10 m-auto">
    <div class="m-auto">
        <?php get_template_part('template-parts/components/section-header', null, [
            'tag' => 'h2',
            'text' => 'Offene Stellen',
        ]); ?>
        <div class="grid grid-cols-1 gap-4">
            <?php if ($jobs->have_posts()) : ?>
                <?php while ($jobs->have_posts()) : $jobs->the_post(); ?>
                    <?php get_template_part('template-parts/components/post-tile'); ?>
                <?php endwhile; ?>
            <?php else : ?>
                
                    <p class="text-center"><?php the_field('no-content') ?></p>
                
            <?php endif; ?>
        </div>
    </div>
</section>