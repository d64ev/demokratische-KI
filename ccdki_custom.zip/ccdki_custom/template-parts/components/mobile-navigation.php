<div 
    id="mobile-nav-container" 
    aria-hidden="true" 
    aria-expanded="false" 
    class="w-screen lg:hidden h-screen overflow-y-scroll flex-col fixed pt-20 px-4 inset-0 bg-black flex bg-transparent group transition-all aria-expanded:bg-d64gray-50 aria-hidden:hidden"
>
<div class="fixed top-0 left-0 w-full h-20 z-10 bg-d64gray-50"></div>

     <!-- mobile search bar template parent -->
     <div class="opacity-0 scale-105 group-aria-expanded:scale-100 group-aria-expanded:opacity-100 transition-all delay-100">
        <?php get_template_part( 'template-parts/components/mobile-search-bar' ); ?>
     </div>
    <h2 id="nav-headline" class="text-2xl pt-4 pb-4 font-semibold scale-105 opacity-0 group-aria-expanded:scale-100 group-aria-expanded:opacity-100 transition-all delay-100 italic">NAVIGATION</h2>    
    
    <?php 
    // Load the main navigation items for the top level navigation
    $main_navigation_items = get_field('main_nav_group', 'option');
    if ($main_navigation_items): ?>

    <!-- If there are main navigation items, load the main navigation -->
    <nav id="top-level-nav" class="h-full flex flex-col justify-between scale-105 opacity-0 group-aria-expanded:scale-100 group-aria-expanded:opacity-100 transition-all delay-100">
        <ul class="flex flex-col w-full pb-32">
            <?php foreach ($main_navigation_items as $item): 
                
                // Loop through each item and load the appropriate markup
                if ($item['main_nav_item_type'] === 'Submenu' ) { ?>
                    <li 
                        data-name="<?php echo esc_html($item['main_nav_item_name'])?>" 
                        class="flex flex-col justify-center py-2"
                    >
                        <button 
                            data-id="<?php echo esc_html($item['main_nav_item_name'])?>"
                            aria-haspopup="true"
                            aria-expended="false"
                            class="mobile-nav-button text-xl font-regular flex justify-between items-center w-full"
                        >
                            <span class="pointer-none">
                                <?php echo esc_html($item['main_nav_item_name'])?>
                            </span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                        </button>
                    </li>
                <?php } else if ($item['main_nav_item_type'] === 'Direct Link' ) { ?>
                    <li class="py-1 border-bottom border-d64blue-900">
                        <a 
                            href="<?php echo esc_html($item['main_nav_direct_link_url']['url'])?>"
                            class="text-xl font-regular flex w-full justify-between items-center"
                        >
                            <?php echo esc_html($item['main_nav_item_name'])?>
                            <!-- add arrow if link is external -->
                            <?php if ($item['main_nav_direct_link_url']['target'] === '_blank' ) : ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-move-up-right"><path d="M13 5H19V11"/><path d="M19 5L5 19"/></svg>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php } ?>
            <?php endforeach; ?>
        </ul>
        <div class="pt-16 pb-32">
        <?php get_template_part( 'template-parts/components/nav-icon-bar' ); ?>
        </div>
    </nav>

    <!-- create the secondary navigation -->
    <?php foreach ($main_navigation_items as $item): 

    // check if item has a sub menu
    if ($item['main_nav_item_type'] === 'Submenu' ) { ?>

        <!-- if item has a submenu, create the submenu -->
        <div 
            id="<?php echo esc_html($item['main_nav_item_name'])?>" 
            class="mobile-nav-sub-menu gap-4 hidden h-full flex-col scale-105 opacity-0 group-aria-expanded:scale-100 group-aria-expanded:opacity-100 transition-all delay-100"
        >
        <div class="pb-32">
            <?php foreach ($item['submenus_group'] as $subitem): ?>
                <div class="p-2 rounded">
                    <!-- SubMenu Name -->
                    <h3 class="font-medium underline pb-1">
                        <?php echo esc_html($subitem['submenu_headline'])?>
                    </h3>
                    <ul>
                    <!-- Create SubMenu Items -->
                    <?php foreach ($subitem['links_group'] as $subItemLink): ?>
                        <li class="ml-2 flex items-center w-full justify-between">
                            <a 
                                href="<?php echo esc_html($subItemLink['link']['url']) ?>"
                                class="py-1 text-xl font-regular w-full"
                            >
                                <?php echo esc_html($subItemLink['link']['title']) ?> 
                                <!-- <?php echo esc_html($subItemLink['link_description']) ?> -->
                            </a>
                            <!-- add arrow if link is external -->
                            <?php if ($subItemLink['link']['target'] === '_blank' ) : ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-move-up-right"><path d="M13 5H19V11"/><path d="M19 5L5 19"/></svg>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
        </div>
    <?php } ?>
    <?php endforeach; ?>
    <?php endif; ?>
</div>