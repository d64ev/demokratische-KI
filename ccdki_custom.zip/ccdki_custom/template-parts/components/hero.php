<?php
/**
 * Template part for displaying a hero section with a h1, a paragraph and links styled like button(s)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */
?>
<?php
    $contentNotCentered = false;
    if (is_page('Presse') || is_page('Impressum') || is_page('Datenschutz') || is_page('Barrierefreiheit') || is_page('Datenschutzerklärung') || is_front_page()) {
        $contentNotCentered = true;
    };
?>

<!-- Hero Section with h1, paragraph and button(s) -->
<section class="pb-12 pt-8 sm:py-20 bg-d64blue-50 sm:bg-transparent" id="hero-content">
    <div class="flex flex-col gap-8 md:gap-10 px-4 max-w-3xl <?php if (!is_front_page()) echo 'm-auto';?>">
        <!-- Don't display the title on the home page -->
        <?php if (!is_front_page()) : ?>
            <h1 class="text-xl md:text-2xl italic font-medium  <?php if (!$contentNotCentered) echo 'sm:text-center align-middle' ?> "><?php the_title(); ?></h1>
        <?php endif; ?>  
        <div class="prose prose-strong:text-d64blue-900   prose-h1:font-bold prose-ul:list-inside  <?php if (!$contentNotCentered) echo 'sm:text-center' ?>">
        <!-- <div class="flex flex-col gap-2 md:gap-3 lg:gap-4 sm:text-center"> -->
            <?php the_content(); ?>
        </div>

        <!-- Display Icons if page is Kontakt -->
        <?php if (is_page('Kontakt')) : ?>
            <div class="flex sm:justify-center">
                <?php get_template_part('template-parts/components/nav-icon-bar') ?>
            </div>
        <?php endif; ?>

        <!-- links that look like buttons -->
        <?php if( have_rows('hero_links') ): ?>
            <div class="flex flex-row flex-wrap gap-2 <?php if (!$contentNotCentered) echo ' sm:items-center sm:justify-center ' ?>">
            <?php while( have_rows('hero_links') ): the_row(); 

                // Get the link sub-field values
                $link = get_sub_field('hero_link');
                $url = $link['url'];
                $title = $link['title'];
                $target = $link['target'] ? $link['target'] : '_self';
                ?>
                <a 
                    href="<?php echo esc_url($url); ?>" 
                    target="<?php echo esc_attr($target); ?>"
                    class="flex px-4 py-[10px]  text-base rounded-full font-medium  max-w-content  bg-d64blue-900 text-white hover:text-d64blue-900 hover:bg-d64blue-500 transition-colors">
                        <?php echo esc_html($title); ?>
                </a>
            <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>
</section>