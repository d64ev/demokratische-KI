<?php
/**
 * Template part for displaying post preview tile
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */
?>

<?php $original_post = $post;
?>

<!-- Wordpress Component for Post Tile with Image, Title with Link, Excerpt, Data and Read More Span -->
<div class="@container h-full">
    <div class="link-tile post-tile group h-full hover:bg-d64blue-50 overflow-hidden cursor-pointer flex flex-col relative transition @md:grid @md:grid-cols-3 @md:gap-4 @md:p-2 [clip-path:polygon(0_0,90%_0,100%_7%,100%_100%,0_100%)] @md:[clip-path:polygon(0_0,95%_0,100%_15%,100%_100%,0_100%)]">
        <?php if (has_category('Job')): ?>
            <div class="absolute top-2 left-2 @md:top-3 @md:left-3 bg-d64blue-900 text-white px-2 py-1 rounded-xl text-xs font-medium">
                Jetzt Bewerben
            </div>
        <?php endif; ?>
        <div class="post-tile__image relative overflow-hidden group-hover:rounded-none aspect-video transition-all">
            <?php the_post_thumbnail('small-16-9'); ?>

        </div>
        <div class="post-tile__content px-2 pt-4 pb-14 @md:pt-0 @md:col-span-2">
            <div class="">
                <div class="post-tile__data hidden @md:flex @md:gap-2 @md:pb-2">
                    <span class="post-tile__date text-xs font-medium text-d64blue-900">
                        <?php the_date(); ?>
                    </span>
                    <?php
                    $linked_author = get_field('author'); 
                    if ($linked_author) : 
                        // Set the post data to the related person post
                        $post = $linked_author[0]; // assuming the relationship returns an array of post objects
                        setup_postdata($post); ?>

                        <span class="text-xs text-d64blue-900 font-medium"><?php the_title(); ?></span>

                        <?php
                        // Reset the post data back to the original post
                        $post = $original_post; 
                        setup_postdata($post);
                        
                    endif; ?>
                </div>
                <h3 class="post-tile__title pb-3">
                    <a href="<?php the_permalink(); ?>" class="text-lg md:text-2xl  font-bold group-hover:underline transition-all">
                        <?php the_title(); ?>
                    </a>
                </h3>
                <div class="post-tile__excerpt">
                    <?php $excerpt = wp_trim_words(get_the_excerpt(), 36, '...');
                    echo $excerpt; ?>
                </div>
            </div>
            <div class="absolute bottom-4 right-4 flex gap-1 group-hover:gap-2 items-center transition-all">
                <span class="post-tile__read-more font-medium">
                        weiterlesen
                </span>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
            </div>
        </div>
    </div>
</div>


