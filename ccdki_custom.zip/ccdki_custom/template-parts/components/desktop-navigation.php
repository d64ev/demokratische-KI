<div 
    id="desktop-nav-container" 
    class="w-max relative px-2"
>   
    <?php 
    // Load the main navigation items for the top level navigation
    $main_navigation_items = get_field('main_nav_group', 'option');
    if ($main_navigation_items): ?>

    <!-- If there are main navigation items, load the main navigation -->
    <nav id="desktop-top-level-nav" class="">
        <ul class="flex flex-row w-full gap-8 items-center font-medium">
            <?php foreach ($main_navigation_items as $item):  
                // Loop through each item and load the appropriate markup
                if ($item['main_nav_item_type'] === 'Submenu' ) { ?>
                    <li 
                        data-name="<?php echo esc_html($item['main_nav_item_name'])?>" 
                        class="relative"
                    >
                        <button 
                            data-id="<?php echo esc_html($item['main_nav_item_name'] . 'desktop')?>"
                            aria-haspopup="true"
                            aria-expanded="false"
                            class="flex z-50 gap-1 items-center desktop-nav-btn group hover:bg-d64blue-50 rounded-lg -mx-2 m-max py-1 px-2 aria-expanded:bg-d64blue-50 transition-colors"
                        >
                            <span class="pointer-none">
                                <?php echo esc_html($item['main_nav_item_name'])?>
                            </span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-down group-aria-expanded:rotate-180 transition-transform"><path d="m6 9 6 6 6-6"/></svg>
                        </button>    
                        <!-- if item has a submenu, create the submenu -->
                        <div 
                            id="<?php echo esc_html($item['main_nav_item_name'] . 'desktop')?>" 
                            class="desktop-nav-sub-menu fixed hidden w-screen left-0 top-0 right-0 -z-10 group"
                            aria-hidden="true"
                            aria-labelled-by="<?php echo esc_html($item['main_nav_item_name'] . 'desktop')?>"
                        >
                            <div class="bg-d64gray-50 bg-opacity-0 group-aria-[hidden=false]:bg-opacity-100 pt-24 px-4 pb-16 w-full transition-all">
                                <div class="max-w-[1200px] m-auto px-4 grid grid-cols-4 gap-4 lg:gap-6 xl:gap-8">
                                    <?php foreach ($item['submenus_group'] as $subitem): ?>
                                        <div class="pt-12">
                                            <!-- SubMenu Name -->
                                            <h3 class=" pb-3 opacity-0 group-aria-[hidden=false]:opacity-100 transition-opacity delay-75 ">
                                                <?php echo esc_html($subitem['submenu_headline'])?>
                                            </h3>
                                            <nav>
                                                <ul class="flex flex-col gap-2">
                                                <!-- Create SubMenu Items -->
                                                <?php foreach ($subitem['links_group'] as $subItemLink): ?>
                                                    <li 
                                                        class= "rounded-xl flex items-center hover:bg-white transition-colors "
                                                        role="menuitem"    
                                                    >
                                                        <a 
                                                            href="<?php echo esc_html($subItemLink['link']['url']) ?>"
                                                            class="text-base  px-2 py-1 flex flex-col opacity-0 group-aria-[hidden=false]:opacity-100 transition-all delay-100"
                                                        >
                                                            <span class="flex gap-1 items-center">
                                                                <span class="font-medium"><?php echo esc_html($subItemLink['link']['title']) ?> </span>
                                                                <!-- add arrow if link is external -->
                                                                <?php if ($subItemLink['link']['target'] === '_blank' ) : ?>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-move-up-right"><path d="M13 5H19V11"/><path d="M19 5L5 19"/></svg>
                                                                <?php endif; ?>
                                                            </span>
                                                            <span class="font-thin"><?php echo esc_html($subItemLink['link_description']) ?></span>
                                                        </a>
                                                    </li>
                                                <?php endforeach; ?>
                                                </ul>
                                            </nav>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </li>                    
                <!-- Main Nav Item is a direct link -->
                <?php } else if ($item['main_nav_item_type'] === 'Direct Link' ) { ?>
                    <li class="z-50">
                        <a 
                            href="<?php echo esc_html($item['main_nav_direct_link_url']['url'])?>"
                            target="<?php echo esc_html($item['main_nav_direct_link_url']['target'])?>"
                            class="hover:bg-d64blue-50 rounded-lg -mx-2 flex m-max py-1 px-2 items-center gap-1 group"
                        >
                            <span>
                                <?php echo esc_html($item['main_nav_item_name'])?>
                            </span>
                            <?php if ($item['main_nav_direct_link_url']['target'] === '_blank' ) : ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-move-up-right"><path d="M13 5H19V11"/><path d="M19 5L5 19"/></svg>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php } ?>
            <?php endforeach; ?>
            <!-- if page is homepage, display link to /english -->
            <!-- <?php if (is_front_page()) : ?>
                <li class="z-50">
                    <a 
                        href="/english"
                        class="hover:bg-d64blue-50 rounded-lg -mx-2 flex m-max py-1 px-2 items-center gap-1 group"
                    >
                        <span>
                            EN
                        </span>
                    </a>
                </li>
            <?php endif; ?> -->
            <!-- Display Search Bar -->
            <li>
                <button 
                    class="px-2 py-2 hover:bg-d64blue-50 rounded-lg -ml-2 transition-colors"
                    aria-expanded="false"
                    aria-haspopup="true"
                    aria-label="Toggle Search Bar"
                    id="toggle-search-bar-btn"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-search"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                </button>
            </li>
        </ul>
    </nav>
<?php endif; ?>
</div>