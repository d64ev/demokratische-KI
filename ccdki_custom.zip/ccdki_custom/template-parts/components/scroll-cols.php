
<?php
if( have_rows('inhalte') ):
?>
<div class=" max-w-3xl m-auto px-4 py-10">
    <?php while( have_rows('inhalte') ) : the_row(); ?>
    <div class="grid grid-cols-5 sm:grid-cols-3 w-full relative">
        <div class="h-full col-span-2 sm:col-span-1">
            <h2 id="scroll-title" class="transition-opacity  font-bold sticky top-[50vh] flex items-center flex-row gap-[2px] sm:gap-1 text-sm sm:text-base text-medium text-64blue-900 border-2 border-d64blue-900 w-fit px-2 sm:px-4 py-1 rounded-full">
                <span ><?php echo get_sub_field('uberschrift'); ?></span>
                <span class="hidden sm:block">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                </span>
                <span class="block sm:hidden">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                </span>
            </h2>
        </div>
        <?php if (have_rows('list')) : ?>
        <ul class="flex flex-col gap-4 col-start-3 col-span-3 sm:col-span-2 sm:col-start-2 pb-10 ">
            <?php while ( have_rows('list') ) : the_row(); ?>
            <li class="sm:text-lg font-medium"><?php echo get_sub_field('item'); ?></li>
            <?php endwhile; ?>
        </ul>
        <?php endif; ?>
        <!-- <div class="absolute h-10 w-full left-0 right-0 top-0 bg-gradient-to-t from-transparent via-white via-10% to-white"></div>
        <div class="absolute h-10 w-full left-0 right-0 bottom-0 bg-gradient-to-b from-transparent via-white via-10% to-white"></div> -->
    </div>
    <?php endwhile; ?>
</div>
<?php endif; ?>
