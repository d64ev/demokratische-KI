<?php
/**
 * Template part for displaying person tile
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */
?>
<!-- tile with person's name, title, short bio and image, Personen is a custom post type -->


<?php 
    $links = get_field('links'); 
    if (isset($links['linkedin']) && $links['linkedin'] || isset($links['email']) && $links['email'] || isset($links['twitter']) && $links['twitter'] || isset($links['facebook']) && $links['facebook'] || isset($links['instagram']) && $links['instagram'] || isset($links['website']) && $links['website']) {
        $social_media = true;
    } else {
        $social_media = false;
    }

    $thumbnail_id = get_post_thumbnail_id();
    $thumbnail_post = get_post($thumbnail_id);
    $thumbnail_desc = esc_html($thumbnail_post->post_content);
    
?>

<div class="@container h-full w-full">
    <!-- add class link tile to make the whole tile clickable -->
    <div class="person-tile group h-full bg-d64blue-50 rounded-xl pt-4 px-4 overflow-hidden flex flex-col relative transition @md:grid @md:grid-cols-3 @md:gap-4">
        <div class="person-tile__image rounded-lg relative overflow-hidden aspect-square @md:mb-4 transition-all "> 
            <?php the_post_thumbnail('medium-1-1'); 
            if (!empty($thumbnail_desc)) {
                echo '<div class="absolute bottom-0 right-0 max-w-max rounded bg-slate-300 bg-opacity-40 text-slate-800  text-xs font-medium text-end px-1 py-[1px]">' . $thumbnail_desc . '</div>';
            }            
    ?>
    </div>
        <div class="person-tile__content <?php if ($social_media === true) { echo 'pb-20'; } else { echo 'pb-4'; }?> pt-4 @md:pt-0 @md:col-span-2">
            <div class="">
                <?php global $linked_author_id;
                if ($linked_author_id || get_post_type() === 'arbeitsgruppe') : ?>
                    <a href="<?php home_url()?>/aktuelles/?author_id=<?php echo get_the_id() ?>" class="text-sm font-medium hover:underline">
                <?php endif; ?>
                    
                <h3 class="person-tile__title pb-3 flex flex-col">
                    <span class="text-lg md:text-2xl  font-bold transition-all">
                        <?php the_title(); ?>
                    </span>
                    <?php if (get_field('funktion')) : ?>
                        <span class="text-sm md:text-base font-medium italic">
                            <?php echo get_field('funktion') ?>
                        </span>
                    <?php endif; ?>
                </h3>
                <?php if ($linked_author_id || get_post_type() === 'arbeitsgruppe') : ?>
                    </a>
                <?php endif; ?>
                <!-- display the DESCRIPTION-->
                <div class="person-tile__excerpt text-sm">
                    <?php if (get_field('desc')) the_field('desc') ?>
                </div>

                <!-- Mitarbeit for Post Author -->
                <?php
                    global $mitarbeit_data;
                    if ($mitarbeit_data) {
                ?> 
                            <div class="flex flex-col flex-wrap pt-4">
                            <h4 class="text-sm font-semibold ">Mitwirkende</h4>
                            <div class="flex flex-wrap gap-1 leading-tight">
                                <?php 
                                    $count = 0;
                                    foreach ($mitarbeit_data as $post): setup_postdata($post); ?>
                                    <div class="">
                                        <span class="text-sm font-regular ">
                                            <?php echo esc_html($post->post_title); ?>
                                        </span>
                                        <?php if (++$count < count($mitarbeit_data)): ?>
                                        <span class="font-medium">, </span>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <?php wp_reset_postdata(); ?>
                            </div>
                        <?php
                    } 
                ?>

                <!-- Koordination for AGs only -->
                <?php
                $koordination = get_field('koordination');
                if ($koordination && !$mitarbeit_data) : ?>
                    <?php $koordination = get_field('koordination'); ?>
                    <div class="flex flex-col flex-wrap pt-4">
                        <h4 class="text-sm font-semibold">Koordination:</h4>
                        <div class="flex gap-1 leading-tight">
                            <?php $koordination = get_field('koordination');
                                $count = 0;
                                foreach ($koordination as $post): setup_postdata($post); ?>
                                <div class="">
                                    <span class="text-sm font-regular">
                                        <?php the_title('', '', $post->ID); ?>
                                    </span>
                                    <?php if (++$count < count($koordination)): ?>
                                    <span class="font-medium">, </span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php wp_reset_postdata(); ?>
                        </div>
                    <?php wp_reset_postdata(); ?>
                <?php endif; ?>
            </div>
            
            <!-- display the fields linkedin, facebook, website and instagram from the group links -->
            <?php if ($social_media === true) : ?>
            <div class="absolute bottom-4 left-4 @md:left-[34.2%] flex flex-row gap-2 items-center transition-all">
                
                <?php $links = get_field('links'); ?>
                    <!-- twitter -->
                    <?php if( isset($links['twitter']) && $links['twitter'] ): ?>
                        <a href="<?php echo esc_url($links['twitter']); ?>" target="_blank" rel="noopener noreferrer">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/twitter.svg" alt="LinkedIn Icon">
                        </a><br>
                    <?php endif; ?>
                    <!-- facebook -->
                    <?php if( isset($links['facebook']) && $links['facebook'] ): ?>
                        <a href="<?php echo esc_url($links['facebook']); ?>" target="_blank" rel="noopener noreferrer">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/facebook.svg" alt="LinkedIn Icon">
                        </a><br>
                    <?php endif; ?>
                    <!-- instagram -->
                    <?php if( isset($links['instagram']) && $links['instagram'] ): ?>
                        <a href="<?php echo esc_url($links['instagram']); ?>" target="_blank" rel="noopener noreferrer">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/instagram.svg" alt="LinkedIn Icon">
                        </a><br>
                    <?php endif; ?>
                    <!-- website -->
                    <?php if( isset($links['website']) && $links['website'] ): ?>
                        <a href="<?php echo esc_url($links['website']); ?>" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/globe.svg" alt="LinkedIn Icon">
                        </a><br>
                    <?php endif; ?>
                    <!-- linkedin -->
                    <?php if( isset($links['linkedin']) && $links['linkedin'] ): ?>
                        <a href="<?php echo esc_url($links['linkedin']); ?>" target="_blank" rel="noopener noreferrer" class="w-5 h-5 flex">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/linkedin.svg" alt="LinkedIn Icon">
                        </a><br>
                    <?php endif; ?>
                    <!-- mastodon -->
                    <?php if( isset($links['mastodon']) && $links['mastodon'] ): ?>
                        <a href="<?php echo esc_url($links['mastodon']); ?>" target="_blank" rel="noopener noreferrer" class="w-5 h-5 flex">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/mdi_mastodon.svg" alt="mastodon Icon">
                        </a><br>
                    <?php endif; ?>
                    <!-- mastodon -->
                    <?php if( isset($links['email']) && $links['email'] ): ?>
                        <a href="mailto:<?php echo esc_url($links['email']); ?>" target="_blank" rel="noopener noreferrer" class="w-5 h-5 flex">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/mail.svg" alt="Email Icon">
                        </a><br>
                    <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>