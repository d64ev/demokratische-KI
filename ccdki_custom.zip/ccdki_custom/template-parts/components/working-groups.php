<?php
/**
 * Template part for displaying the working groups
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */

$arbeitsgruppen = get_posts(array(
    'post_type' => 'arbeitsgruppe',
    'numberposts' => -1,
    'orderby' => 'title',
    'order' => 'ASC',
    // 'tax_query' => array(
    //     array(
    //         'taxonomy' => 'role',
    //         'field'    => 'slug',
    //         'terms'    => 'author',
    //     ),
    // ),
));

global $post;
$post->arbeitsgruppen = $arbeitsgruppen;
?>

<div class="max-w-3xl m-auto py-10">
    <?php get_template_part('template-parts/components/section-header', null, array('text' => 'Unsere Arbeitsgruppen')); ?>
    <div class="flex flex-col gap-4 px-4">
    <?php foreach ( $arbeitsgruppen as $post) : setup_postdata($post); ?>
                        
        <?php get_template_part('template-parts/components/person-tile'); ?>
                        
    <?php endforeach; ?>
    </div>
</div>

<?php wp_reset_postdata(); ?>
