
<?php
/**
 * Template part for displaying section headline
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */
?>

<!-- Wordpress Component for Section Headline with Section Title (h2 or h3) -->

<?php
    $tag = $args['tag'] ?? 'h2'; // Set a default value of h2 if none is provided
    $text = $args['text'] ?? ''; // Default to an empty string if no text is provided
?>

<div class="section-header w-full pb-8 sm:pb-8 md:pb-12 lg:pb-16">
    <<?php echo $tag; ?> class="section-header__title text-lg text-lila-500 sm:text-xl italic text-center m-auto font-medium">
        <?php echo $text; ?>
    </<?php echo $tag; ?>>
</div>

