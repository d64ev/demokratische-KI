<?php
/**
 * Template part for Tabs
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package d64
 */
?>


<?php
// Fetch the 'tab' repeater field
$tabs = get_field('tab');

// Check if there is any row of data
if ($tabs) : ?>

    <!-- Tabs Component -->
    <section class="max-w-3xl m-auto py-10">
        <!-- check if $tabs has more than one tab -->
        <div class="max-w-2xl flex flex-col gap-8">
            <div class="px-4 w-full overflow-x-scroll">
                <div class="tab-selector flex gap-1 <?php if (count($tabs) === 1 ) echo 'hidden'?>">
                    <?php foreach ($tabs as $key => $tab) : ?>
                        <button class="tab-selector__button bg-white border-2 border-d64blue-50 hover:bg-d64blue-50 rounded-full px-4 font-medium py-1 transition-colors" id="tab-button-<?php echo $key; ?>" data-tab-id="<?php echo $key; ?>">
                            <?php echo $tab['label'] ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>            
            <div class="tab-content px-4">
                <?php foreach ($tabs as $key => $tab) : ?>
                    <div class="tab-content__item hidden ml-0 prose prose-neutral prose-a:text-primary prose-h2:text-lg sm:pose-h2:text-xl prose-h2:italic" id="tab-content-<?php echo $key; ?>">
                        <h2 class=" font-bold"><?php echo $tab['label'] ?></h2>
                        <?php echo $tab['content'] ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

<?php endif; ?>

<style>
    .tab-selector::-webkit-scrollbar {
        display: none;
    }

    .tab-selector {
        -ms-overflow-style: none;  /* IE and Edge */
        scrollbar-width: none;  /* Firefox */
    }

</style>