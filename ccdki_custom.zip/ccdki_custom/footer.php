<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the `#content` element and all content thereafter.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package d64
 */

?>

	</div><!-- #content -->
	<div class="border-y border-lila-500/30 max-w-5xl mx-auto mt-16 md:mt-20">
		<img src="<?php echo get_template_directory_uri(); ?>/assets/images/BMFSFJ.jpg" class="max-w-sm w-full mt-2">
	</div>

	<?php  get_template_part( 'template-parts/layout/footer', 'content' ); ?>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
