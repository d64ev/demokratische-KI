<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package d64
 */

get_header();
?>

	<section id="primary">
		<main id="main">

			<?php
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content/content', 'single' );

				
				// End the loop.
			endwhile;
			?>

		</main><!-- #main -->
	</section><!-- #primary -->
	 
	<?php if (get_the_ID() == 20837) : ?>
	<!-- Dimensionen KI-Wertekompass Section -->

            <!-- Section Header Data -->
            <?php 
                $argsHeader = [
                    'tag' => 'h2',
                    'text' => 'KI-Wertekompass',
                ];
            ?>
            <section id="ki-wertekompass" class="py-6 px-4 sm:pt-12 lg:pt-16 max-w-screen-md mx-auto">
            
                <!-- Section Header -->
                <?php get_template_part('template-parts/components/section-header', null, $argsHeader) ?>
            
                <!-- Slider Container -->
                <div id="slider-container" class="max-w-5xl lg:mx-auto px-4 py-6 border border-lila-500 sm:px-6 sm:py-12">
                <div class="space-y-6">
                    <!-- Slider 1 -->
                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">Sicherheit</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">Offenheit</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-full max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>

                <!-- Slider 2 -->
                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">Konservativ</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">Explorativ</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-full max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>

                <!-- Remaining sliders follow same pattern -->
                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">Präzision</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">Imagination</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-full max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>

                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">Menschliche Autor:innenschaft</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">KI-generierte Inhalte</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-full max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>

                <div class="slider-row grid grid-rows-[auto,1fr] grid-cols-2 sm:grid-rows-1 sm:grid-cols-[1fr,3fr,1fr] md:grid-cols-[1fr,2.5fr,1fr] sm:gap-4 sm:items-center">
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-1 flex sm:items-center sm:justify-self-end sm:text-end">KI-Minimalismus</span>
                    <span class="text-gray-700 text-sm font-semibold row-start-1 col-start-2 flex max-sm:justify-self-end sm:col-start-3 sm:items-center">KI-Maximierung</span>
                    <div class="relative row-start-2 col-start-1 col-span-2 w-[100%+1rem] max-sm:mt-2 sm:row-start-1 sm:col-start-2 sm:col-span-1">
                        <div class="h-8 bg-lila-500/15 rounded-full">
                            <div class="slider-thumb" style="left: 50%"></div>
                        </div>
                        <input type="range" class="absolute inset-0 w-full h-8 opacity-0 cursor-pointer" value="50">
                    </div>
                </div>
            </div>
        </div>

            <!-- Download Button -->
            <div class="flex mx-4 lg:mx-auto justify-end max-w-5xl">
                <button id="downloadBtn" class="mt-6 px-4 py-2 bg-lila-500 text-white rounded hover:bg-lila-500/80 transition-colors">
                    Screenshot generieren
                </button>
            </div>
        </section>
		<?php endif; ?>

<?php
get_footer();
