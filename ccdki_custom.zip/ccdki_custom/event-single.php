<!-- STYLES ARE OVERWRITTEN IN THE FILE: /tailwind/custom/base.css -->
<?php
/* Template Name: Single Event Page */

get_header();
$currentUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<?php 
    global $EM_Event, $post;
    if( empty($EM_Event) ) {
        $EM_Event = em_get_event($post->ID, 'post_id');
        ?>
        <div class="<?php em_template_classes('view-container'); ?>" id="em-view-<?php echo $id; ?>" data-view="event">
	        <div class="<?php em_template_classes('event-single'); ?> em-event-<?php echo esc_attr($EM_Event->event_id); ?> <?php if( $EM_Event->active_status == 0 ) echo 'em-event-cancelled'; ?>" id="em-event-<?php echo $id; ?>" data-view-id="<?php echo $id; ?>">
                <article id="event-article">
                    <header class="entry-header pt-4 sm:pt-8 md:pt-12 lg:pt-16 xl:pt-20 md:pb-2 lg:pb-4 xl:pb-6">
                        <div class="max-w-2xl px-4 m-auto">
                            <h1 class="font-sans !text-lila-500 !font-bold !text-xl"><?php echo $EM_Event->event_name; ?></h1>

                            <!-- date and category, excerpt container -->
                            <div class="flex">

                                <!-- excerpt -->
                                <div class="text-md leading-loose font-medium sm:text-lg sm:col-span-2">
                                    <?php 
                                    $event_description = get_post_field('post_excerpt', $EM_Event->post_id);
                                    echo wpautop($event_description);
                                    ?>
                                </div>
                            </div>
                        </div>
                    </header><!-- .entry-header -->

                    <!-- post thumbnail and dates -->
                    <div class="m-auto  bg-d64blue-50">
                            <div class="flex flex-col-reverse sm:py-8 sm:grid sm:grid-cols-2 max-w-4xl md:gap-8 m-auto">

                                <!-- Event Image -->
                                <?php if ($EM_Event->output('#_EVENTIMAGE{large-16-9}')) : ?>
                                    <div class="aspect-video sm:aspect-auto sm:mx-4 sm:overflow-hidden sm:object-fill relative ">	
                                        <?php 
                                            $image = $EM_Event->output('#_EVENTIMAGE{medium-16-9}');
                                            $image_id = get_post_thumbnail_id($EM_Event->post_id);
                                            $image_with_class = str_replace('<img ', '<img class="h-auto aspect-video @lg:max-h-[320px] @3xl:max-h-[400px] w-full object-cover " id="your-id-name" ', $image);
                                            $image_post = get_post($image_id);
                                            $image_description = $image_post ? $image_post->post_content : '';

                                            echo $image_with_class;
                                            if ($image_description) {
                                                echo '<div class="absolute bottom-0 right-0 max-w-max rounded-tl bg-slate-300 bg-opacity-80 text-slate-800  text-xs font-medium text-end px-1 py-[1px]">' . $image_description . '</div>';
                                            }
                                        ?>
                                    </div>
                                <?php endif; ?>

                                <!-- Event Details -->
                                <div class="py-8 px-4 sm:py-4 bg-d64blue-50 flex flex-col gap-8 sm:gap-10 md:gap-12 text-d64blue-900">
                                    <!-- Date and Time -->
                                    <div class="grid grid-cols-2">
                                        <span class="text-sm font-semibold pt-[1px]">wann</span>
                                        <div class="flex flex-col gap-1">
                                            <!-- Event Date -->
                                            <span class="font-medium text-xl">            
                                                <?php echo $EM_Event->output('#_EVENTDATES'); ?>
                                            </span>
                                            <!-- Even Time -->
                                            <span class="font-medium text-xl ">
                                                <?php echo $EM_Event->output('#_EVENTTIMES') . ' Uhr'; ?>
                                            </span>
                                        </div>
                                    </div>
                                    <!-- Event Location -->
                                    <div class="grid grid-cols-2">
                                        <span class="text-sm font-semibold pt-[1px]">wo</span>
                                        <div class="flex flex-col">
                                            <span class="font-bold text-xl pb-1">
                                                <?php echo $EM_Event->output('#_LOCATIONNAME'); ?>
                                            </span>
                                            <span class="font-medium text-base">    
                                                <?php echo $EM_Event->output('#_LOCATIONADDRESS'); ?>
                                            </span>
                                            <span class="font-medium text-base">
                                                <?php echo $EM_Event->output('#_LOCATIONTOWN'); ?>
                                            </span>
                                            <span class="font-medium text-base">
                                                <?php echo $EM_Event->output('#_LOCATIONSTATE'); ?> 
                                            </span>
                                            <!-- Website -->
                                            <?php if ($EM_Event->output('#_EVENTLOCATION{url} ')) : ?>
                                                <a href="<?php echo $EM_Event->output('#_EVENTLOCATION{url} '); ?>" class="font-medium pt-0 !text-d64blue-900 text-base hover:underline">
                                                    <?php echo $EM_Event->output('#_EVENTLOCATION{text}'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <!-- Booking Link -->
                                    <?php if( $EM_Event->get_bookings()->is_open() ) : ?>
                                        <div class="grid grid-cols-2">
                                            <span class="text-sm font-semibold pt-[1px]">anmelden</span>
                                            <div class="flex flex-col">
                                                <a href="#anmeldung" id="veranstaltung-anmeldung-button">
                                                    <div class="w-full flex justify-center">
                                                        <span class="text-white !hover:text-blue-500 pointer-events-none">Jetzt anmelden</span>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>  
                            </div>
                        </div>

                    <!-- event description -->
                    <div class="desc px-4 pt-4 sm:pt-8 md:pt-10 lg:pt-12 xl:pt-14 max-w-2xl m-auto">
                        <div <?php d64_content_class( 'entry-content' ); ?>>
                            <?php 
                                $event_description = get_post_field('post_content', $EM_Event->post_id);
                                echo wpautop($event_description);
                            ?>
                        </div><!-- .entry-content -->
                    </div>
                </article>
                                    
                <!-- Event Registration -->
                <?php if( $EM_Event->get_bookings()->is_open() ) : ?>
                    <div class="sm:px-4 max-w-2xl m-auto">
                        <div id="anmeldung" class="prose !prose-h3:text-lg  px-4 pb-8 sm:mx-auto pt-8 mt-16  prose-button:bg-red-500  bg-d64blue-50 booking sm:rounded-xl">
                            <?php  echo $EM_Event->output('#_BOOKINGFORM'); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php
        } else {
            echo 'failed to load the event';
        }
?>

<?php get_footer(); ?>