<?php
/* Template Name: Projekt Page */

get_header();

// Get the custom color
$main_color = get_field('main_color');
$main_color = $main_color ? $main_color : '#6B46C1';
$ueberschrift = get_field('ueberschrift');
?>

<!-- get the ansprechpartner from relationship field ansprechpartner -->
<?php $ansprechpartner = get_field('ansprechpartner:in'); ?>

<section id="primary" class="bg-white">
    <main id="main" class="max-w-screen overflow-x-clip lg:max-w-[1200px] m-auto -mb-28 sm:-mt-[95px] pt-[95px] max-sm:pb-12 md:pt-[110px]">          
        <!-- Cusstom Projekt Page -->
        <div id="projekt" class="lg:grid lg:grid-cols-[1fr_352px] gap-4 lg:px-4 xl:px-0">
            <div class="">
                <div class="">
                    <!-- Section with h1, paragraph and button(s) -->
                <section class="pb-12 pt-8 sm:py-20 bg-transparent" id="hero-content">
                    <div class="flex flex-col gap-8 md:gap-10 px-4 max-w-3xl">
                         <!-- logo custom field, image array -->
                        <?php if (get_field('logo')) : ?>
                            <div class="flex justify-start lg:hidden">
                                <?php $logo = get_field('logo'); ?>
                                <img src="<?php echo esc_url($logo['url']); ?>" alt="<?php echo esc_attr($logo['alt']); ?>" class="w-auto max-h-[120px] h-auto object-contain" />
                            </div>
                        <?php endif; ?>

                        <h1 class="text-xl md:text-2xl italic font-medium custom-color"><?php the_title(); ?></h1>
                        
                        <!-- Excerpt -->
                        <!-- <div class="prose prose-lg prose-strong:text-d64blue-900   prose-h1:font-bold prose-ul:list-inside prose-headings:custom-color">
                            <?php the_excerpt(); ?>
                        </div>  -->

                        <!-- Dislplay Image -->
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="flex justify-center">
                                <?php the_post_thumbnail('medium_large', ['class' => 'w-full h-auto ratio-video !rounded-none']) ?>
                            </div>
                        <?php endif; ?>


                         <!-- Ansprechperson mobile / tablet -->
                        <?php if ($ansprechpartner) : ?>
                            <div class="lg:hidden">
                                <?php get_template_part('template-parts/components/ansprechpartner', null, [
                                    'ansprechpartner' => $ansprechpartner, 
                                    'main_color' => $main_color,
                                    'is_desktop' => false
                                ]); ?>
                            </div>
                        <?php endif; ?>

                        <div class="prose prose-strong:text-d64blue-900   prose-h1:font-bold prose-ul:list-inside prose-headings:custom-color prose-img:!rounded-none">
                            <?php the_content(); ?>
                        </div>

                        <!-- links that look like buttons -->
                        <?php if( have_rows('hero_links') ): ?>
                            <div class="flex flex-row flex-wrap gap-2">
                            <?php while( have_rows('hero_links') ): the_row(); 

                                // Get the link sub-field values
                                $link = get_sub_field('hero_link');
                                $url = $link['url'];
                                $title = $link['title'];
                                $target = $link['target'] ? $link['target'] : '_self';
                                ?>
                                <a 
                                    href="<?php echo esc_url($url); ?>" 
                                    target="<?php echo esc_attr($target); ?>"
                                    class="flex px-4 py-[10px]  text-base rounded-full font-medium  max-w-content  bg-d64blue-900 text-white hover:text-d64blue-900 hover:bg-d64blue-500 transition-colors">
                                        <?php echo esc_html($title); ?>
                                </a>
                            <?php endwhile; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                <!-- Förderlogos, custom field forderer, image array -->
                <?php if (get_field('forderer')) : ?>
                    <div class="py-8 px-4 sm:py-12 sm:bg-transparent max-w-screen overflow-clip">
                        <div class="flex flex-col gap-4 max-w-3xl">
                            <h2 class="text-xl md
                            :text-2xl font-medium text-d64blue-900">
                                <?php if ($ueberschrift) {
                                    echo esc_html($ueberschrift);
                                } else {
                                    echo 'Gefördert von:';
                                } ?>
                            </h2>
                            <div class="flex flex-wrap items-center gap-8 mt-4 max-w-[100vw-32px] overflow-clip">
                                <?php $foerderer = get_field('forderer'); ?>
                                <?php foreach ($foerderer as $foerderer) : ?>
                                    <img src="<?php echo esc_url($foerderer['url']); ?>" alt="<?php echo esc_attr($foerderer['alt']); ?>" class="w-auto max-sm:max-w-[100vw-32px] flex max-w-[500px] max-h-[250px] object-contain" />
                                <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
                </section>
                </div>

                
            </div>
            
            <!-- sidebar -->
             <div class="mt-10 sm:mt-20 sm:max-w-[320px] flex flex-col gap-8">
            
             <!-- logo custom field -->
            <?php if (get_field('logo')) : ?>
                <div class="flex justify-start max-lg:hidden">
                    <?php $logo = get_field('logo'); ?>
                    <img src="<?php echo esc_url($logo['url']); ?>" alt="<?php echo esc_attr($logo['alt']); ?>" class="w-auto max-h-[160px] h-auto object-contain" />
                </div>
            <?php endif; ?>
            <!-- Ansprechpartner Section -->
            <?php if ($ansprechpartner) : ?>     
                <div class="ansprechperson-desktop hidden lg:block">
                    <?php get_template_part('template-parts/components/ansprechpartner', null, [
                        'ansprechpartner' => $ansprechpartner, 
                        'main_color' => $main_color,
                        'is_desktop' => true
                    ]); ?>
                </div>               
            <?php endif; ?>
        </div>
        </div>
    </main>
</section>

<?php get_footer(); ?>

<style>
    #projekt h1,
    #projekt h2,
    #projekt h3,
    #projekt h4,
    #projekt h5 {
        font-family: 'Saira', sans-serif;
    }

    .custom-color {
        color: <?php echo esc_attr($main_color); ?>;
    }
    .custom-border {
        border-color: <?php echo esc_attr($main_color); ?>;
    }

    .prose h1, 
    .prose h2,
    .prose h3,
    .prose h4,
    .prose h5 {
        color: <?php echo esc_attr($main_color); ?> !important;
    }

    #projekt .wp-element-button {
        background-color: <?php echo esc_attr($main_color); ?> !important;
    }

</style>